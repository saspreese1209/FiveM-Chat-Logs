fx_version 'bodacious'
game 'gta5'

server_script "chatlogs_s.lua"